import numpy as np
import os
if os.name == "nt": os.system("cls")

def crear_matrices():
    global departamentos
    global tipo_depa
    global precio_depa
    global clientes
    global depa
    precio_depa = {
        "A": 3800,
        "B": 3000,
        "C": 2800,
        "D": 3500
    }
    tipo_depa = {
        "A": 0,
        "B": 1,
        "C": 2,
        "D": 3
    }
    departamentos = [[" "] * 4 for i in range(10)]
    depa = list(reversed(departamentos))
    clientes = []

def menu():
    global op
    print("\n")
    print("1) Comprar departamento")
    print("2) Mostrar departamento")
    print("3) Ver listado de compradores")
    print("4) Mostrar ganancias totales")
    print("5) Salir")
    op = int(input("Ingrese una opcion:  "))
    print("\n")

def mostrar_departamentos():
    depas = np.array(depa)
    print("=====DEPARTAMENTOS=====")
    print("   =====TIPO=====")
    print("   A | B | C | D")
    print(depas)
    input("")

def comprar_departamento():
    global tipo
    while True:
        piso = int(input("Ingrese el piso del departamento que desea:  "))
        tipo = input("Ingrese el tipo de departamento que desea:  ").upper()
        if piso <= 10 and piso >= 1 and tipo == "A" or tipo == "B" or tipo == "C" or tipo == "D":
            piso -= 1
            if departamentos[piso][tipo_depa[tipo]] == " ":
                departamentos[piso][tipo_depa[tipo]] = "X"
                ingresar_cliente()
                guardar_venta()
                print("Piso comprado con exito")
                break
            else:
                print("El departamento no esta disponible.")
        else:
            print("El departamento ingresado es invalido")    

def ingresar_cliente():
    while True:
        try:
            rut_cliente = int(input("Ingrese su RUT (sin puntos ni guion):  "))
            clientes.extend([[rut_cliente]])
            break
        except:
            print("Los datos ingresados son invalido")

def mostrar_clientes():
    clientes.sort()
    numcliente = 1
    print("=====CLIENTES=====")
    if clientes == []:
        print("No hay clientes")
    else:
        for f in range(len(clientes)):
            print(f"   Cliente nro {numcliente}")
            for c in range(len(clientes[f])):
                print(clientes[f][c])
            numcliente += 1
            print("\n")
    input("")

def guardar_venta():
    global total_a,total_b,total_c,total_d,cantidad_a,cantidad_b,cantidad_c,cantidad_d,cantidad_total,total
    if tipo == "A":
        total_a += precio_depa[tipo]
        total += precio_depa[tipo]
        cantidad_a += 1
        cantidad_total += 1
    elif tipo == "B":
        total_b += precio_depa[tipo]
        cantidad_b += 1
        cantidad_total += 1
        total += precio_depa[tipo]
    elif tipo == "C":
        total_c += precio_depa[tipo]
        cantidad_c += 1
        cantidad_total += 1
        total += precio_depa[tipo]
    elif tipo == "D":
        total_d += precio_depa[tipo]
        cantidad_d += 1
        cantidad_total += 1
        total += precio_depa[tipo]

def mostrar_ventas():
        print("Tipo de Departamento | Cantidad | Total")
        print("---------------------------------------")
        print(f"Tipo A 3.800 UF      | {cantidad_a}        | {total_a}")
        print("---------------------------------------")
        print(f"Tipo B 3.000 UF      | {cantidad_b}        | {total_b}")
        print("---------------------------------------")
        print(f"Tipo C 2.800 UF      | {cantidad_c}        | {total_c}")
        print("---------------------------------------")
        print(f"Tipo D 3.500 UF      | {cantidad_d}        | {total_d}")
        print("---------------------------------------")
        print(f"Total                | {cantidad_total}        | {total}")
        print("---------------------------------------")
        input("")

def salir_aplicacion():
    global menus
    print("Usted salio de la aplicacion, Adios.")
    print("Sebastian Torres")
    print("10-07-2023")
    menus = False

crear_matrices()
total_a = 0
total_b = 0
total_c = 0
total_d = 0
cantidad_a = 0
cantidad_b = 0
cantidad_c = 0
cantidad_d = 0
cantidad_total = 0
total = 0
menus = True

while menus == True:
    try:
        menu()
        if op == 1:
            comprar_departamento()
        elif op == 2:
            mostrar_departamentos()
        elif op == 3:
            mostrar_clientes()
        elif op == 4:
            mostrar_ventas()
        elif op == 5:
            salir_aplicacion()
        else:
            print("La opcion ingresada es invalida")
    except:
        print("Debe ingresar un numero")
